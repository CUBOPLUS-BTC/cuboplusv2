declare class Events {
    private _eventType;
    private _eventFunctions;
    constructor(eventType: string, eventFunctions?: EventListener[]);
    init(): void;
}
export default Events;
//# sourceMappingURL=events.d.ts.map