export declare function initFlowbite(): void;
//# sourceMappingURL=index.d.ts.map