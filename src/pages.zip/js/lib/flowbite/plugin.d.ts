declare const plugin: { handler: () => void };
export = plugin;
